﻿using CLADII_TextBasedAdventure.BackEndContent;
using CLADII_TextBasedAdventure.EntityContent;
using CLADII_TextBasedAdventure.PlayerContent;
using CLADII_TextBasedAdventure.SaveSystem;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CLADII_TextBasedAdventure.FrontEndContent
{
    public static class MainMenu
    {
        public static bool InMainMenu()
        {
            Utils.LbL(@"──────────────────────────────────────────────────────────────────────────────────────────────────
─██████████████─██████─────────██████████████─████████████──────────────────██████████─██████████─
─██░░░░░░░░░░██─██░░██─────────██░░░░░░░░░░██─██░░░░░░░░████────────────────██░░░░░░██─██░░░░░░██─
─██░░██████████─██░░██─────────██░░██████░░██─██░░████░░░░██────────────────████░░████─████░░████─
─██░░██─────────██░░██─────────██░░██──██░░██─██░░██──██░░██──────────────────██░░██─────██░░██───
─██░░██─────────██░░██─────────██░░██████░░██─██░░██──██░░██─██████████████───██░░██─────██░░██───
─██░░██─────────██░░██─────────██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██───██░░██─────██░░██───
─██░░██─────────██░░██─────────██░░██████░░██─██░░██──██░░██─██████████████───██░░██─────██░░██───
─██░░██─────────██░░██─────────██░░██──██░░██─██░░██──██░░██──────────────────██░░██─────██░░██───
─██░░██████████─██░░██████████─██░░██──██░░██─██░░████░░░░██────────────────████░░████─████░░████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░████────────────────██░░░░░░██─██░░░░░░██─
─██████████████─██████████████─██████──██████─████████████──────────────────██████████─██████████─
──────────────────────────────────────────────────────────────────────────────────────────────────
", ConsoleColor.DarkRed, speedCustom: true);

            Utils.LbL(@"1. New Game
2. Load Game
3. Settings
4. Exit Game", speedCustom: true);

            string input = Utils.GetInput();

            switch (input)
            {
                case "1":
                    {
                        Playtime.StartPlaytime();
                        PlayerCreator.CreatePlayer();
                        SaveData.Save();
                        return false;
                    }
                case "2":
                    {
                        Playtime.StartPlaytime();
                        HumanEntity.player = SaveData.Load();
                        if (HumanEntity.player == null)
                        {
                            Thread.Sleep(1000);
                            Console.Clear();
                            return true;
                        }
                        return false;
                    }
                case "3":
                    {
                        SettingsMenu.InSettings();
                        return true;
                    }
                case "4":
                    {
                        Environment.Exit(0);
                        Playtime.ResetPlaytime();
                        return false;
                    }
                default:
                    {
                        Utils.LbL("Input a valid number.", speedCustom: true);
                        Thread.Sleep(1000);
                        Console.Clear();
                        return true;
                    }
            }
        }
    }
}
