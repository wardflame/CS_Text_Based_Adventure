﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CLADII_TextBasedAdventure.FrontEndContent
{
    public class SettingsMenu
    {
        public static void InSettings()
        {
            bool inSettings = true;
            while (inSettings)
            {
                Console.Clear();
                Utils.LbL(@"
▒█▀▀▀█ ▒█▀▀▀ ▀▀█▀▀ ▀▀█▀▀ ▀█▀ ▒█▄░▒█ ▒█▀▀█ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█▀▀▀ ░▒█░░ ░▒█░░ ▒█░ ▒█▒█▒█ ▒█░▄▄ ░▀▀▀▄▄ 
▒█▄▄▄█ ▒█▄▄▄ ░▒█░░ ░▒█░░ ▄█▄ ▒█░░▀█ ▒█▄▄█ ▒█▄▄▄█
", ConsoleColor.Magenta, speedCustom: true);
                Utils.LbL("1. Type Speed\n2. Return to Main Menu", speedCustom: true);

                string input = Utils.GetInput();
                switch (input)
                {
                    case "1":
                        {
                            Utils.LbL($"\nChoose a speed (in milliseconds) at which game text is printed character-by-character.\nDefault: 30\nCurrent: {Utils.textSpeed}\nNew speed (input # between 0-1000): ", speedCustom: true, newLine: false);
                            bool checkingInput = true;
                            while (checkingInput)
                            {
                                input = Utils.GetInput();
                                if (!int.TryParse(input, out int inputNum) || inputNum < 0 || inputNum > 1000)
                                {
                                    Utils.LbL("\nInput a valid number.", speedCustom: true);
                                }
                                else
                                {
                                    Utils.textSpeed = inputNum;
                                    Utils.LbL($"\nText speed set to: {Utils.textSpeed}");
                                    Thread.Sleep(1000);
                                    checkingInput = false;
                                }
                            }
                        }
                        break;
                    case "2":
                        {
                            Console.Clear();
                            inSettings = false;
                        }
                        break;
                    default:
                        {
                            Utils.LbL("Input a valid number.", speedCustom: true);
                            Console.Clear();
                        }
                        break;
                }
            }
        }
    }
}
