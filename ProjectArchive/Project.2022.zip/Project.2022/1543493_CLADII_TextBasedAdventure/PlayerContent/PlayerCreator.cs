﻿using CLADII_TextBasedAdventure.EntityContent;
using System;
using System.Collections.Generic;
using System.Text;

namespace CLADII_TextBasedAdventure.PlayerContent
{
    public static class PlayerCreator
    {
        public static void CreatePlayer()
        {
            Utils.LbL(@"
Looking over your shoulder at the crowd being shoved around behind you,
you climb up into the bus and run your wrist over the pay scanner.

    Two seconds,
    three seconds,
    payment checks green.
    You tuck away into one of the back seats, peeking out a side window.

    Four men, tattooed and openly carrying pistols, look around frantically,
pushing panicked civs away. They split up, going for a bus each, but just as
a burly one can come up to your bus, the driver shuts his door and pulls off
from the depot, despite the goon's attempts to bang on the bus' side.

    Looking out the back window, you watch the men reconvene, frustrated and
arguing.

    It's over...

    For the first time in the last forty-eight hours, you can
sit down and ", newLine: false);
            Utils.LbL("breathe...", ConsoleColor.Blue);
            Utils.LbL("Input name: ", newLine: false);
            HumanEntity.player.name = Utils.GetInput();
        }
    }
}
