﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CLADII_TextBasedAdventure.ProfessionContent
{
    class Abilities
    {
    }
}
