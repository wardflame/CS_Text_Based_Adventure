﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CLADII_TextBasedAdventure.ProfessionContent
{
    public class Profession
    {
        string name;
        List<Abilities> abilities = new List<Abilities>();
    }
}
