﻿using CLADII_TextBasedAdventure.BackEndContent;
using CLADII_TextBasedAdventure.EntityContent;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CLADII_TextBasedAdventure.SaveSystem
{
    class SaveData
    {
        // NEED SAVE OBJECT WITH ALL INFORMATION STORED IN IT.
        public static void Directories()
        {
            if (!Directory.Exists($"Saves"))
            {
                Directory.CreateDirectory($"Saves");
            }
        }

        public static void Save()
        {
            if (!Directory.Exists($"Saves\\{HumanEntity.player.name}"))
            {
                Directory.CreateDirectory($"Saves\\{HumanEntity.player.name}");
            }
            HumanEntity.player.playtime = Playtime.GetSessionLengthInMils();
            string save = JsonConvert.SerializeObject($"{HumanEntity.player.playtime:H:mm:ss}.json");
            File.WriteAllText($"Saves\\{HumanEntity.player.name}", save);
        }

        public static bool GetSaves()
        {
            Directories();
            var direc = Directory.GetFiles("Saves");
            if (direc.Length == 0)
            {
                Utils.LbL("\nThere are no saves available.");
                return false;
            }
            else
            {
                return true;
            }
        }

        public static HumanEntity Load()
        {
            bool getSaves = GetSaves();
            if (!getSaves)
            {
                return null;
            }
            else
            {
                return JsonConvert.DeserializeObject<HumanEntity>(File.ReadAllText($"Saves\\{HumanEntity.player.name}\\"));
            }
        }
    }
}
