﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CLADII_TextBasedAdventure.LevelContent.Dustbowl
{
    public class BusStation : Map
    {
        public BusStation() : base("Bus Station", Location.BusStation)
        {
        }
    }
}
